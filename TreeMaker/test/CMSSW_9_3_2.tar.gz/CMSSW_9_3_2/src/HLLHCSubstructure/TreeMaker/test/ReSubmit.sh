#python ReSubmit.py -i GENSIMnew.RSGluonToTT_M-3000_TuneCUETP8M1_14TeV-pythia8v2-v1_PU200
#python ReSubmit.py -i GENSIMnew.RSGluonToTT_M-4000_TuneCUETP8M1_14TeV-pythia8v2-v1_PU200
#python ReSubmit.py -i GENSIMnew.RSGluonToTT_M-5000_TuneCUETP8M1_14TeV-pythia8v2-v1_PU200

#python ReSubmit.py -i GENSIMnew.QCD_Flat_Pt-15to7000_TuneCUETP8M1_14TeV_pythia8v2-v1_PU200
#python ReSubmit.py -i GENSIMnew.TT_TuneCUETP8M2T4_14TeV-powheg-pythia8v2-v1_PU200
#python ReSubmit.py -i GENSIMnew.QCD_Mdijet-1000toInf_TuneCUETP8M1_14TeV-pythia8v2-v1_PU200
python ReSubmit.py -i GENSIMnew.TT_Mtt1500toInf_TuneCUETP8M1_14TeV-powheg-pythia8v2-v1_PU200
