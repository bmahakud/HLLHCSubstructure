rm *.stdout
rm *.stderr
rm *.condor
