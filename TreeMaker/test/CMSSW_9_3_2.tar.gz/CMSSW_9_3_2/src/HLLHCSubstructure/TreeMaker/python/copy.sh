file=$1

scp ./${1} bmahakud@lxplus.cern.ch:/afs/cern.ch/user/b/bmahakud/work/TMP
