supportedJetAlgos = { 'ak': 'AntiKt', 'ca' : 'CambridgeAachen', 'kt' : 'Kt' }
for type, tmpAlgo in supportedJetAlgos.iteritems(): 
                   print tmpAlgo
