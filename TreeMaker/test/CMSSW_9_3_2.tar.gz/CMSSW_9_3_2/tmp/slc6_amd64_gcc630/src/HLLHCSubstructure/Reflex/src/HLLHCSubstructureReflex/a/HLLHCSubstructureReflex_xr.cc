// Do NOT change. Changes will be lost next time file is generated

#define R__DICTIONARY_FILENAME tmpdIslc6_amd64_gcc630dIsrcdIHLLHCSubstructuredIReflexdIsrcdIHLLHCSubstructureReflexdIadIHLLHCSubstructureReflex_xr

/*******************************************************************/
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#define G__DICTIONARY
#include "RConfig.h"
#include "TClass.h"
#include "TDictAttributeMap.h"
#include "TInterpreter.h"
#include "TROOT.h"
#include "TBuffer.h"
#include "TMemberInspector.h"
#include "TInterpreter.h"
#include "TVirtualMutex.h"
#include "TError.h"

#ifndef G__ROOT
#define G__ROOT
#endif

#include "RtypesImp.h"
#include "TIsAProxy.h"
#include "TFileMergeInfo.h"
#include <algorithm>
#include "TCollectionProxyInfo.h"
/*******************************************************************/

#include "TDataMember.h"

// Since CINT ignores the std namespace, we need to do so in this file.
namespace std {} using namespace std;

// Header files passed as explicit arguments
#include "src/HLLHCSubstructure/Reflex/src/classes.h"

// Header files passed via #pragma extra_include

namespace ROOT {
   static TClass *edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR_Dictionary();
   static void edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR_TClassManip(TClass*);
   static void *new_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR(void *p = 0);
   static void *newArray_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR(Long_t size, void *p);
   static void delete_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR(void *p);
   static void deleteArray_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR(void *p);
   static void destruct_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::edm::Wrapper<vector<TLorentzVector> >*)
   {
      ::edm::Wrapper<vector<TLorentzVector> > *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::edm::Wrapper<vector<TLorentzVector> >));
      static ::ROOT::TGenericClassInfo 
         instance("edm::Wrapper<vector<TLorentzVector> >", ::edm::Wrapper<vector<TLorentzVector> >::Class_Version(), "DataFormats/Common/interface/Wrapper.h", 25,
                  typeid(::edm::Wrapper<vector<TLorentzVector> >), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR_Dictionary, isa_proxy, 4,
                  sizeof(::edm::Wrapper<vector<TLorentzVector> >) );
      instance.SetNew(&new_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR);
      instance.SetNewArray(&newArray_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR);
      instance.SetDelete(&delete_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR);
      instance.SetDeleteArray(&deleteArray_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR);
      instance.SetDestructor(&destruct_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR);

      ::ROOT::AddClassAlternate("edm::Wrapper<vector<TLorentzVector> >","edm::Wrapper<std::vector<TLorentzVector> >");
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::edm::Wrapper<vector<TLorentzVector> >*)
   {
      return GenerateInitInstanceLocal((::edm::Wrapper<vector<TLorentzVector> >*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::edm::Wrapper<vector<TLorentzVector> >*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::edm::Wrapper<vector<TLorentzVector> >*)0x0)->GetClass();
      edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR_TClassManip(theClass);
   return theClass;
   }

   static void edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR_Dictionary();
   static void edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR_TClassManip(TClass*);
   static void *new_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR(void *p = 0);
   static void *newArray_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR(Long_t size, void *p);
   static void delete_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR(void *p);
   static void deleteArray_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR(void *p);
   static void destruct_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::edm::Wrapper<vector<vector<TLorentzVector> > >*)
   {
      ::edm::Wrapper<vector<vector<TLorentzVector> > > *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::edm::Wrapper<vector<vector<TLorentzVector> > >));
      static ::ROOT::TGenericClassInfo 
         instance("edm::Wrapper<vector<vector<TLorentzVector> > >", ::edm::Wrapper<vector<vector<TLorentzVector> > >::Class_Version(), "DataFormats/Common/interface/Wrapper.h", 25,
                  typeid(::edm::Wrapper<vector<vector<TLorentzVector> > >), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR_Dictionary, isa_proxy, 4,
                  sizeof(::edm::Wrapper<vector<vector<TLorentzVector> > >) );
      instance.SetNew(&new_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR);
      instance.SetNewArray(&newArray_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR);
      instance.SetDelete(&delete_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR);
      instance.SetDeleteArray(&deleteArray_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR);
      instance.SetDestructor(&destruct_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR);

      ::ROOT::AddClassAlternate("edm::Wrapper<vector<vector<TLorentzVector> > >","edm::Wrapper<std::vector<std::vector<TLorentzVector> > >");
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::edm::Wrapper<vector<vector<TLorentzVector> > >*)
   {
      return GenerateInitInstanceLocal((::edm::Wrapper<vector<vector<TLorentzVector> > >*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::edm::Wrapper<vector<vector<TLorentzVector> > >*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::edm::Wrapper<vector<vector<TLorentzVector> > >*)0x0)->GetClass();
      edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR_TClassManip(theClass);
   return theClass;
   }

   static void edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR_Dictionary();
   static void edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR_TClassManip(TClass*);
   static void *new_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR(void *p = 0);
   static void *newArray_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR(Long_t size, void *p);
   static void delete_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR(void *p);
   static void deleteArray_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR(void *p);
   static void destruct_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >*)
   {
      ::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> > *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >));
      static ::ROOT::TGenericClassInfo 
         instance("edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >", ::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >::Class_Version(), "DataFormats/Common/interface/Wrapper.h", 25,
                  typeid(::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR_Dictionary, isa_proxy, 4,
                  sizeof(::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >) );
      instance.SetNew(&new_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR);
      instance.SetNewArray(&newArray_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR);
      instance.SetDelete(&delete_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR);
      instance.SetDeleteArray(&deleteArray_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR);
      instance.SetDestructor(&destruct_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >*)
   {
      return GenerateInitInstanceLocal((::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >*)0x0)->GetClass();
      edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR_TClassManip(theClass);
   return theClass;
   }

   static void edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *edmcLcLPtrVectorlEpatcLcLPackedCandidategR_Dictionary();
   static void edmcLcLPtrVectorlEpatcLcLPackedCandidategR_TClassManip(TClass*);
   static void *new_edmcLcLPtrVectorlEpatcLcLPackedCandidategR(void *p = 0);
   static void *newArray_edmcLcLPtrVectorlEpatcLcLPackedCandidategR(Long_t size, void *p);
   static void delete_edmcLcLPtrVectorlEpatcLcLPackedCandidategR(void *p);
   static void deleteArray_edmcLcLPtrVectorlEpatcLcLPackedCandidategR(void *p);
   static void destruct_edmcLcLPtrVectorlEpatcLcLPackedCandidategR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::edm::PtrVector<pat::PackedCandidate>*)
   {
      ::edm::PtrVector<pat::PackedCandidate> *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::edm::PtrVector<pat::PackedCandidate>));
      static ::ROOT::TGenericClassInfo 
         instance("edm::PtrVector<pat::PackedCandidate>", ::edm::PtrVector<pat::PackedCandidate>::Class_Version(), "DataFormats/Common/interface/PtrVector.h", 103,
                  typeid(::edm::PtrVector<pat::PackedCandidate>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &edmcLcLPtrVectorlEpatcLcLPackedCandidategR_Dictionary, isa_proxy, 4,
                  sizeof(::edm::PtrVector<pat::PackedCandidate>) );
      instance.SetNew(&new_edmcLcLPtrVectorlEpatcLcLPackedCandidategR);
      instance.SetNewArray(&newArray_edmcLcLPtrVectorlEpatcLcLPackedCandidategR);
      instance.SetDelete(&delete_edmcLcLPtrVectorlEpatcLcLPackedCandidategR);
      instance.SetDeleteArray(&deleteArray_edmcLcLPtrVectorlEpatcLcLPackedCandidategR);
      instance.SetDestructor(&destruct_edmcLcLPtrVectorlEpatcLcLPackedCandidategR);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::edm::PtrVector<pat::PackedCandidate>*)
   {
      return GenerateInitInstanceLocal((::edm::PtrVector<pat::PackedCandidate>*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::edm::PtrVector<pat::PackedCandidate>*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *edmcLcLPtrVectorlEpatcLcLPackedCandidategR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::edm::PtrVector<pat::PackedCandidate>*)0x0)->GetClass();
      edmcLcLPtrVectorlEpatcLcLPackedCandidategR_TClassManip(theClass);
   return theClass;
   }

   static void edmcLcLPtrVectorlEpatcLcLPackedCandidategR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::edm::Wrapper<vector<TLorentzVector> > : new ::edm::Wrapper<vector<TLorentzVector> >;
   }
   static void *newArray_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::edm::Wrapper<vector<TLorentzVector> >[nElements] : new ::edm::Wrapper<vector<TLorentzVector> >[nElements];
   }
   // Wrapper around operator delete
   static void delete_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR(void *p) {
      delete ((::edm::Wrapper<vector<TLorentzVector> >*)p);
   }
   static void deleteArray_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR(void *p) {
      delete [] ((::edm::Wrapper<vector<TLorentzVector> >*)p);
   }
   static void destruct_edmcLcLWrapperlEvectorlETLorentzVectorgRsPgR(void *p) {
      typedef ::edm::Wrapper<vector<TLorentzVector> > current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::edm::Wrapper<vector<TLorentzVector> >

namespace ROOT {
   // Wrappers around operator new
   static void *new_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::edm::Wrapper<vector<vector<TLorentzVector> > > : new ::edm::Wrapper<vector<vector<TLorentzVector> > >;
   }
   static void *newArray_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::edm::Wrapper<vector<vector<TLorentzVector> > >[nElements] : new ::edm::Wrapper<vector<vector<TLorentzVector> > >[nElements];
   }
   // Wrapper around operator delete
   static void delete_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR(void *p) {
      delete ((::edm::Wrapper<vector<vector<TLorentzVector> > >*)p);
   }
   static void deleteArray_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR(void *p) {
      delete [] ((::edm::Wrapper<vector<vector<TLorentzVector> > >*)p);
   }
   static void destruct_edmcLcLWrapperlEvectorlEvectorlETLorentzVectorgRsPgRsPgR(void *p) {
      typedef ::edm::Wrapper<vector<vector<TLorentzVector> > > current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::edm::Wrapper<vector<vector<TLorentzVector> > >

namespace ROOT {
   // Wrappers around operator new
   static void *new_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> > : new ::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >;
   }
   static void *newArray_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >[nElements] : new ::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >[nElements];
   }
   // Wrapper around operator delete
   static void delete_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR(void *p) {
      delete ((::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >*)p);
   }
   static void deleteArray_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR(void *p) {
      delete [] ((::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >*)p);
   }
   static void destruct_edmcLcLWrapperlEedmcLcLPtrVectorlEpatcLcLPackedCandidategRsPgR(void *p) {
      typedef ::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> > current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >

namespace ROOT {
   // Wrappers around operator new
   static void *new_edmcLcLPtrVectorlEpatcLcLPackedCandidategR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::edm::PtrVector<pat::PackedCandidate> : new ::edm::PtrVector<pat::PackedCandidate>;
   }
   static void *newArray_edmcLcLPtrVectorlEpatcLcLPackedCandidategR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::edm::PtrVector<pat::PackedCandidate>[nElements] : new ::edm::PtrVector<pat::PackedCandidate>[nElements];
   }
   // Wrapper around operator delete
   static void delete_edmcLcLPtrVectorlEpatcLcLPackedCandidategR(void *p) {
      delete ((::edm::PtrVector<pat::PackedCandidate>*)p);
   }
   static void deleteArray_edmcLcLPtrVectorlEpatcLcLPackedCandidategR(void *p) {
      delete [] ((::edm::PtrVector<pat::PackedCandidate>*)p);
   }
   static void destruct_edmcLcLPtrVectorlEpatcLcLPackedCandidategR(void *p) {
      typedef ::edm::PtrVector<pat::PackedCandidate> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::edm::PtrVector<pat::PackedCandidate>

namespace ROOT {
   static TClass *vectorlEvectorlEpatcLcLJetgRsPgR_Dictionary();
   static void vectorlEvectorlEpatcLcLJetgRsPgR_TClassManip(TClass*);
   static void *new_vectorlEvectorlEpatcLcLJetgRsPgR(void *p = 0);
   static void *newArray_vectorlEvectorlEpatcLcLJetgRsPgR(Long_t size, void *p);
   static void delete_vectorlEvectorlEpatcLcLJetgRsPgR(void *p);
   static void deleteArray_vectorlEvectorlEpatcLcLJetgRsPgR(void *p);
   static void destruct_vectorlEvectorlEpatcLcLJetgRsPgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<vector<pat::Jet> >*)
   {
      vector<vector<pat::Jet> > *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<vector<pat::Jet> >));
      static ::ROOT::TGenericClassInfo 
         instance("vector<vector<pat::Jet> >", -2, "vector", 214,
                  typeid(vector<vector<pat::Jet> >), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEvectorlEpatcLcLJetgRsPgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<vector<pat::Jet> >) );
      instance.SetNew(&new_vectorlEvectorlEpatcLcLJetgRsPgR);
      instance.SetNewArray(&newArray_vectorlEvectorlEpatcLcLJetgRsPgR);
      instance.SetDelete(&delete_vectorlEvectorlEpatcLcLJetgRsPgR);
      instance.SetDeleteArray(&deleteArray_vectorlEvectorlEpatcLcLJetgRsPgR);
      instance.SetDestructor(&destruct_vectorlEvectorlEpatcLcLJetgRsPgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<vector<pat::Jet> > >()));
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<vector<pat::Jet> >*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEvectorlEpatcLcLJetgRsPgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<vector<pat::Jet> >*)0x0)->GetClass();
      vectorlEvectorlEpatcLcLJetgRsPgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEvectorlEpatcLcLJetgRsPgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEvectorlEpatcLcLJetgRsPgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<vector<pat::Jet> > : new vector<vector<pat::Jet> >;
   }
   static void *newArray_vectorlEvectorlEpatcLcLJetgRsPgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<vector<pat::Jet> >[nElements] : new vector<vector<pat::Jet> >[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEvectorlEpatcLcLJetgRsPgR(void *p) {
      delete ((vector<vector<pat::Jet> >*)p);
   }
   static void deleteArray_vectorlEvectorlEpatcLcLJetgRsPgR(void *p) {
      delete [] ((vector<vector<pat::Jet> >*)p);
   }
   static void destruct_vectorlEvectorlEpatcLcLJetgRsPgR(void *p) {
      typedef vector<vector<pat::Jet> > current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<vector<pat::Jet> >

namespace ROOT {
   static TClass *vectorlEvectorlETLorentzVectorgRsPgR_Dictionary();
   static void vectorlEvectorlETLorentzVectorgRsPgR_TClassManip(TClass*);
   static void *new_vectorlEvectorlETLorentzVectorgRsPgR(void *p = 0);
   static void *newArray_vectorlEvectorlETLorentzVectorgRsPgR(Long_t size, void *p);
   static void delete_vectorlEvectorlETLorentzVectorgRsPgR(void *p);
   static void deleteArray_vectorlEvectorlETLorentzVectorgRsPgR(void *p);
   static void destruct_vectorlEvectorlETLorentzVectorgRsPgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<vector<TLorentzVector> >*)
   {
      vector<vector<TLorentzVector> > *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<vector<TLorentzVector> >));
      static ::ROOT::TGenericClassInfo 
         instance("vector<vector<TLorentzVector> >", -2, "vector", 214,
                  typeid(vector<vector<TLorentzVector> >), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEvectorlETLorentzVectorgRsPgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<vector<TLorentzVector> >) );
      instance.SetNew(&new_vectorlEvectorlETLorentzVectorgRsPgR);
      instance.SetNewArray(&newArray_vectorlEvectorlETLorentzVectorgRsPgR);
      instance.SetDelete(&delete_vectorlEvectorlETLorentzVectorgRsPgR);
      instance.SetDeleteArray(&deleteArray_vectorlEvectorlETLorentzVectorgRsPgR);
      instance.SetDestructor(&destruct_vectorlEvectorlETLorentzVectorgRsPgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<vector<TLorentzVector> > >()));
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<vector<TLorentzVector> >*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEvectorlETLorentzVectorgRsPgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<vector<TLorentzVector> >*)0x0)->GetClass();
      vectorlEvectorlETLorentzVectorgRsPgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEvectorlETLorentzVectorgRsPgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEvectorlETLorentzVectorgRsPgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<vector<TLorentzVector> > : new vector<vector<TLorentzVector> >;
   }
   static void *newArray_vectorlEvectorlETLorentzVectorgRsPgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<vector<TLorentzVector> >[nElements] : new vector<vector<TLorentzVector> >[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEvectorlETLorentzVectorgRsPgR(void *p) {
      delete ((vector<vector<TLorentzVector> >*)p);
   }
   static void deleteArray_vectorlEvectorlETLorentzVectorgRsPgR(void *p) {
      delete [] ((vector<vector<TLorentzVector> >*)p);
   }
   static void destruct_vectorlEvectorlETLorentzVectorgRsPgR(void *p) {
      typedef vector<vector<TLorentzVector> > current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<vector<TLorentzVector> >

namespace ROOT {
   static TClass *vectorlEpatcLcLJetgR_Dictionary();
   static void vectorlEpatcLcLJetgR_TClassManip(TClass*);
   static void *new_vectorlEpatcLcLJetgR(void *p = 0);
   static void *newArray_vectorlEpatcLcLJetgR(Long_t size, void *p);
   static void delete_vectorlEpatcLcLJetgR(void *p);
   static void deleteArray_vectorlEpatcLcLJetgR(void *p);
   static void destruct_vectorlEpatcLcLJetgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<pat::Jet>*)
   {
      vector<pat::Jet> *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<pat::Jet>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<pat::Jet>", -2, "vector", 214,
                  typeid(vector<pat::Jet>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEpatcLcLJetgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<pat::Jet>) );
      instance.SetNew(&new_vectorlEpatcLcLJetgR);
      instance.SetNewArray(&newArray_vectorlEpatcLcLJetgR);
      instance.SetDelete(&delete_vectorlEpatcLcLJetgR);
      instance.SetDeleteArray(&deleteArray_vectorlEpatcLcLJetgR);
      instance.SetDestructor(&destruct_vectorlEpatcLcLJetgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<pat::Jet> >()));
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<pat::Jet>*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEpatcLcLJetgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<pat::Jet>*)0x0)->GetClass();
      vectorlEpatcLcLJetgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEpatcLcLJetgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEpatcLcLJetgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<pat::Jet> : new vector<pat::Jet>;
   }
   static void *newArray_vectorlEpatcLcLJetgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<pat::Jet>[nElements] : new vector<pat::Jet>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEpatcLcLJetgR(void *p) {
      delete ((vector<pat::Jet>*)p);
   }
   static void deleteArray_vectorlEpatcLcLJetgR(void *p) {
      delete [] ((vector<pat::Jet>*)p);
   }
   static void destruct_vectorlEpatcLcLJetgR(void *p) {
      typedef vector<pat::Jet> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<pat::Jet>

namespace ROOT {
   static TClass *vectorlETLorentzVectorgR_Dictionary();
   static void vectorlETLorentzVectorgR_TClassManip(TClass*);
   static void *new_vectorlETLorentzVectorgR(void *p = 0);
   static void *newArray_vectorlETLorentzVectorgR(Long_t size, void *p);
   static void delete_vectorlETLorentzVectorgR(void *p);
   static void deleteArray_vectorlETLorentzVectorgR(void *p);
   static void destruct_vectorlETLorentzVectorgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<TLorentzVector>*)
   {
      vector<TLorentzVector> *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<TLorentzVector>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<TLorentzVector>", -2, "vector", 214,
                  typeid(vector<TLorentzVector>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlETLorentzVectorgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<TLorentzVector>) );
      instance.SetNew(&new_vectorlETLorentzVectorgR);
      instance.SetNewArray(&newArray_vectorlETLorentzVectorgR);
      instance.SetDelete(&delete_vectorlETLorentzVectorgR);
      instance.SetDeleteArray(&deleteArray_vectorlETLorentzVectorgR);
      instance.SetDestructor(&destruct_vectorlETLorentzVectorgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<TLorentzVector> >()));
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<TLorentzVector>*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlETLorentzVectorgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<TLorentzVector>*)0x0)->GetClass();
      vectorlETLorentzVectorgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlETLorentzVectorgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlETLorentzVectorgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<TLorentzVector> : new vector<TLorentzVector>;
   }
   static void *newArray_vectorlETLorentzVectorgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<TLorentzVector>[nElements] : new vector<TLorentzVector>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlETLorentzVectorgR(void *p) {
      delete ((vector<TLorentzVector>*)p);
   }
   static void deleteArray_vectorlETLorentzVectorgR(void *p) {
      delete [] ((vector<TLorentzVector>*)p);
   }
   static void destruct_vectorlETLorentzVectorgR(void *p) {
      typedef vector<TLorentzVector> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<TLorentzVector>

namespace {
  void TriggerDictionaryInitialization_HLLHCSubstructureReflex_xr_Impl() {
    static const char* headers[] = {
0    };
    static const char* includePaths[] = {
"/uscms_data/d3/bmahakud/TDRTestVersion_v3/CMSSW_9_3_2/src",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/cms/cmssw/CMSSW_9_3_2/src",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/lcg/root/6.10.04-ghjeda/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/external/boost/1.63.0-mlhled2/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/external/pcre/8.37-oenich/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/external/bz2lib/1.0.6/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/external/clhep/2.3.4.2-mlhled2/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/external/gsl/2.2.1/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/external/hepmc/2.06.07-oenich/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/external/libuuid/2.22.2/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/external/python/2.7.11-mlhled2/include/python2.7",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/external/tbb/2017_20161004oss/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/cms/vdt/v0.3.2-oenich/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/external/xerces-c/3.1.3/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/external/xz/5.2.2-oenich/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/external/zlib-x86_64/1.2.11/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/external/md5/1.0.0/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/external/tinyxml/2.5.3-mlhled2/include",
"/cvmfs/cms.cern.ch/slc6_amd64_gcc630/lcg/root/6.10.04-ghjeda/include",
"/uscms_data/d3/bmahakud/TDRTestVersion_v3/CMSSW_9_3_2/",
0
    };
    static const char* fwdDeclCode = R"DICTFWDDCLS(
#line 1 "HLLHCSubstructureReflex_xr dictionary forward declarations' payload"
#pragma clang diagnostic ignored "-Wkeyword-compat"
#pragma clang diagnostic ignored "-Wignored-attributes"
#pragma clang diagnostic ignored "-Wreturn-type-c-linkage"
extern int __Cling_Autoloading_Map;
namespace pat{class __attribute__((annotate("$clingAutoload$DataFormats/PatCandidates/interface/Jet.h")))  Jet;}
namespace std{template <typename _Tp> class __attribute__((annotate("$clingAutoload$bits/allocator.h")))  __attribute__((annotate("$clingAutoload$string")))  allocator;
}
class __attribute__((annotate("$clingAutoload$TLorentzVector.h")))  TLorentzVector;
namespace pat{class __attribute__((annotate("$clingAutoload$DataFormats/PatCandidates/interface/PackedCandidate.h")))  PackedCandidate;}
namespace edm{template <typename T> class __attribute__((annotate("$clingAutoload$DataFormats/Common/interface/HolderToVectorTrait_Ptr_specialization.h")))  __attribute__((annotate("$clingAutoload$DataFormats/PatCandidates/interface/Jet.h")))  PtrVector;
}
)DICTFWDDCLS";
    static const char* payloadCode = R"DICTPAYLOAD(
#line 1 "HLLHCSubstructureReflex_xr dictionary payload"

#ifndef G__VECTOR_HAS_CLASS_ITERATOR
  #define G__VECTOR_HAS_CLASS_ITERATOR 1
#endif
#ifndef CMS_DICT_IMPL
  #define CMS_DICT_IMPL 1
#endif
#ifndef _REENTRANT
  #define _REENTRANT 1
#endif
#ifndef GNUSOURCE
  #define GNUSOURCE 1
#endif
#ifndef __STRICT_ANSI__
  #define __STRICT_ANSI__ 1
#endif
#ifndef GNU_GCC
  #define GNU_GCC 1
#endif
#ifndef _GNU_SOURCE
  #define _GNU_SOURCE 1
#endif
#ifndef CMSSW_GIT_HASH
  #define CMSSW_GIT_HASH "CMSSW_9_3_2"
#endif
#ifndef PROJECT_NAME
  #define PROJECT_NAME "CMSSW"
#endif
#ifndef PROJECT_VERSION
  #define PROJECT_VERSION "CMSSW_9_3_2"
#endif
#ifndef TBB_USE_GLIBCXX_VERSION
  #define TBB_USE_GLIBCXX_VERSION 60300
#endif
#ifndef BOOST_SPIRIT_THREADSAFE
  #define BOOST_SPIRIT_THREADSAFE 1
#endif
#ifndef PHOENIX_THREADSAFE
  #define PHOENIX_THREADSAFE 1
#endif
#ifndef CMSSW_REFLEX_DICT
  #define CMSSW_REFLEX_DICT 1
#endif

#define _BACKWARD_BACKWARD_WARNING_H
#include <vector>
#include "TLorentzVector.h"
#include "DataFormats/PatCandidates/interface/Jet.h"
#include "DataFormats/Common/interface/Wrapper.h"
#include "DataFormats/Common/interface/PtrVector.h"
#include "DataFormats/PatCandidates/interface/PackedCandidate.h"

namespace {
  struct dictionary {
    std::vector<TLorentzVector> vlv;
    std::vector<pat::Jet> vpj;
    std::vector<std::vector<TLorentzVector> > vvlv;
    std::vector<std::vector<pat::Jet> > vvpj;
	edm::PtrVector<pat::PackedCandidate> rv2pp;
    edm::Wrapper<std::vector<TLorentzVector> > wvlv;
    edm::Wrapper<std::vector<std::vector<TLorentzVector> > > wvvlv;
	edm::Wrapper<edm::PtrVector<pat::PackedCandidate> > wrv2pp;
  };
}

#undef  _BACKWARD_BACKWARD_WARNING_H
)DICTPAYLOAD";
    static const char* classesHeaders[]={
"edm::PtrVector<pat::PackedCandidate>", payloadCode, "@",
"edm::Wrapper<edm::PtrVector<pat::PackedCandidate> >", payloadCode, "@",
"edm::Wrapper<std::vector<TLorentzVector> >", payloadCode, "@",
"edm::Wrapper<std::vector<std::vector<TLorentzVector> > >", payloadCode, "@",
"edm::Wrapper<vector<TLorentzVector> >", payloadCode, "@",
"edm::Wrapper<vector<vector<TLorentzVector> > >", payloadCode, "@",
nullptr};

    static bool isInitialized = false;
    if (!isInitialized) {
      TROOT::RegisterModule("HLLHCSubstructureReflex_xr",
        headers, includePaths, payloadCode, fwdDeclCode,
        TriggerDictionaryInitialization_HLLHCSubstructureReflex_xr_Impl, {}, classesHeaders);
      isInitialized = true;
    }
  }
  static struct DictInit {
    DictInit() {
      TriggerDictionaryInitialization_HLLHCSubstructureReflex_xr_Impl();
    }
  } __TheDictionaryInitializer;
}
void TriggerDictionaryInitialization_HLLHCSubstructureReflex_xr() {
  TriggerDictionaryInitialization_HLLHCSubstructureReflex_xr_Impl();
}
